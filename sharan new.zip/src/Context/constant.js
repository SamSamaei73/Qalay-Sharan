export const SERVER_URL = "http://qalaybitumen.com/Api/v1";
// export const SERVER_URL = "http://localhost:3000/api/v1";
